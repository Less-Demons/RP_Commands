const { activity } = require('../settings/config').Settings;

module.exports = {
  execute: async (Client) => {
    Client.user.setPresence({
      status: activity.status,
      activity: {
        name: activity.game,
        type: activity.type,
      },
    });

    process.on('unhandledRejection', (error) => {
      console.log(`[Error] An error ocurred in process: \n${error.stack}`);
    });

    process.on('uncaughtException', (exception) => {
      console.log(
        `[Error] An exception ocurred in process: \n${exception.stack}`
      );
    });

    console.log(
      `[Info] ${Client.user.username} has been successufully logged in!`
    );

    setInterval(() => {
      require('../functions/UpdateAuction')(Client);
    }, 10000);
  },
  name: 'ready',
};
