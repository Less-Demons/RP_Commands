const { Commands } = require('../settings/config');

module.exports = {
    execute: async(Client, message) => {
        if (message.author.bot) return;
        if (message.guild === null) return;

        if (!message.content.startsWith(Commands.command_prefix)) return;
        if (Commands.blacklisted_channels.includes(message.channel.id)) return;

        const args = message.content
            .slice(Commands.command_prefix.length)
            .split(/ +/);
        const name = args.shift().toLowerCase();

        const command =
            Client.commands.get(name) ||
            Client.commands.get(Client.aliases.get(name));

        if (command)
            try {
                command.execute(Client, message, args);
            } catch (error) {
                console.log(
                    `[Error] Command: ${command.name} | Message: ${error.message}`
                );
            }
    },
    name: 'message',
};