const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async(Client, message, args) => {
        const user = message.mentions.users.first()

        if (!message.member.roles.cache.some(e => Client.config.Commands.cuff_roles.includes(e.id))) return message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription('You are not LEO therefore can not uncuff people, please roleplay getting the cuffs off!'))
        if (!user) return message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription('You need to mention a user to give your ID to!'))
      
        message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription(`💳 ${message.author} has gave their ID to ${user}.`))
        await message.delete()
    },
    config: {
        name: 'giveid',
        aliases: [],
    },
};