const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async(Client, message, args) => {

        await message.delete()
        
        message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription(`⛽️ ${message.author} 
        *Unscrews Gas cap
        Selects premium gas
        Pays for gas
        Takes gas nozzle off of pump and puts into gas tank
        Starts pumping gas
        click
        Stops pumping gas 
        Takes nozzle out of tank and puts into pump
        Closes gas cap
        pays*.`))
    },
    config: {
        name: 'fuel',
        aliases: [],
    },
};