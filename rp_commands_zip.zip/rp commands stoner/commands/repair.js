const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async(Client, message, args) => {

        await message.delete()
        
        message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription(`🛠 ${message.author} has repaired their car.`))
    },
    config: {
        name: 'repair',
        aliases: [],
    },
};