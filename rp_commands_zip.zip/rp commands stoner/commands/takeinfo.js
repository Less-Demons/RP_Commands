const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async(Client, message, args) => {
        const user = message.mentions.users.first()

        if (!user) return message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription('You need to mention a user to take the info of!'))
      
        message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription(`📄 ${message.author} has taken ${user}'s relivent info.`))
        await message.delete()
    },
    config: {
        name: 'takereg',
        aliases: [],
    },
};