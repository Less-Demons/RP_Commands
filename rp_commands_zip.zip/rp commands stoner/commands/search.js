const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async(Client, message, args) => {
        const user = message.mentions.users.first()

        if (!user) return message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription('You need to mention a user to search!'))
      await message.delete()
        
        message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription(`${message.author} is now searching ${user}.
        __What do they find?__`))
    },
    config: {
        name: 'search',
        aliases: [],
    },
};