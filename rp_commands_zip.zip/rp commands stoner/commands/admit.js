const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async (Client, message, args) => {
        if (!message.member.roles.cache.some(e => Client.config.Commands.admit_roles.includes(e.id))) return message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription('You are not Fire and EMS therefore can not admit people to hospital!'))

        const user = message.mentions.users.first()
        const hospital = require('parse-duration')(args.slice(1).join(' '))
        const time = require('parse-duration')(args.slice(2).join(''))

        if (!user) return message.channel.send(new MessageEmbed({color: Client.config.Commands.embed_color}).setDescription('Please mention a user to admit!'))
        if (!hospital) return message.channel.send(new MessageEmbed({color: Client.config.commands.embed_color}).SetDescription(`Please give me a hospital to admit ${user} to.`))
        if ([null, Infinity].includes(time)) return message.channel.send(new MessageEmbed({color: Client.config.Commands.embed_color}).setDescription('You need to enter a time! Ex: `2d5m`'))
        await message.delete()

        message.channel.send(new MessageEmbed({color: Client.config.Commands.embed_color}).setDescription(`${message.author} has admitted ${user} to ${args.slice(1).join(' ')}`))
},
    config: {
        name: 'admit',
        aliases: [],
    },
};