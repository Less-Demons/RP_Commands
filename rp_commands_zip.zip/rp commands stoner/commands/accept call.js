const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async(Client, message, args) => {
        const user = message.mentions.users.first()

        if (!user) return message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription('You need to mention a user to accept the call!'))
      
        message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription(`📞 ${message.author} has accepted ${user}'s call.`))
        await message.delete()
    },
    config: {
        name: 'acceptcall',
        aliases: [],
    },
};