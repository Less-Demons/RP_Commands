const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async(Client, message, args) => {
        const user = message.mentions.users.first()

        if (!message.member.roles.cache.some(e => Client.config.Commands.cuff_roles.includes(e.id))) return message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription('You are not LEO therefore can not cuff people!'))
        if (!user) return message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription('You need to mention a user to cuff!'))
      await message.delete()
        
        message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription(`${message.author} has cuffed ${user}.`))
    },
    config: {
        name: 'cuff',
        aliases: [],
    },
};