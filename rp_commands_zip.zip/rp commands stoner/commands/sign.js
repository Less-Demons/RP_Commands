const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async(Client, message, args) => {
        const user = message.mentions.users.first()

        if (!user) return message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription('You need to mention a user to give the ticket back to!'))
      
        message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription(`🎫 ${message.author} has signed their ticket and given it back to ${user}.`))
        await message.delete()
    },
    config: {
        name: 'sign',
        aliases: [],
    },
};