const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async(Client, message, args) => {
        const user = message.mentions.users.first()
      
        message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription(`📞 ${message.author} is now calling ${user}.`))
        await message.delete()
    },
    config: {
        name: 'call',
        aliases: [],
    },
};