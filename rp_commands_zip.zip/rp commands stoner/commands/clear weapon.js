const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async(Client, message, args) => {

        await message.delete()
        
        message.channel.send(new MessageEmbed({ color: Client.config.Commands.embed_color }).setDescription(`${message.author} 
        Opens doors,
        Opens trunk,
        Looks for aabnormalities in the vehicle,
        Searches abnormalities,
        Searches rest of vehicle.,*
        **__What do they find?__**.`))
    },
    config: {
        name: 'clearweapon',
        aliases: [],
    },
};