const { MessageEmbed } = require("discord.js");

module.exports = {
    execute: async(Client, message, args) => {
        if (!args[0]) return message.channel.send(new MessageEmbed({color: Client.config.Commands.embed_color}).setDescription('Enter something for me to say!'))
        await message.delete()
        message.channel.send(new MessageEmbed({color: Client.config.Commands.embed_color}).setDescription(`${message.author} ${args.join(' ')}`))
    },
    config: {
        name: 'me',
        aliases: [],
    },
};