module.exports = {
    Settings: {
        token: 'Bot-token',
        activity: {
            game: 'whatever you want here',
            type: 'PLAYING', //WATCHING, PLAYING, LISTENING
        },
        status: 'ONLINE'
    },
    Commands: {
        blacklisted_channels: [],
        command_prefix: '$',
        embed_color: 'RED',
        admit_roles: ['role-id'],
        cuff_roles: ['Role-id']
    },
    //IGNORE BELOW HERE!!!!!!!!!!
    Auctions: {
        category: 'CATEGORYID',
        max_time: '6h',
    },
    TimeSheets: {
        channel: 'CHANNELID',
    },
};