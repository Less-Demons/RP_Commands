const { MessageEmbed } = require('discord.js');
const moment = require('moment');
require('moment-duration-format');

module.exports = async(Client) => {
    const indexes = Client.auctions.indexes;

    for (let number = 0; number < indexes.length; number++) {
        const index = indexes[number];

        const {
            message,
            item,
            seller,
            duration,
            price,
            max_bid,
        } = Client.auctions.get(index);

        const msg = await Client.channels.cache.get(index).messages.fetch(message);

        if (Date.now() > duration) {
            const embed = new MessageEmbed()
                .setTitle(item)
                .setDescription(
                    `
 Seller: ${Client.users.cache.get(seller)}     
Price: **$${price}**
 Duration: **Expired**
 Winner: ${Client.users.cache.get(max_bid.user)}`
                )
                .setColor(Client.color);
            msg.edit(embed);

            await Client.channels.cache
                .get(index)
                .send(
                    `Congratulations to ${Client.users.cache.get(
            max_bid.user
          )} for **WINNING** the bidding war!`
                );

            await Client.auctions.delete(index);

            return;
        }

        if (!msg) continue;

        const embed = new MessageEmbed()
            .setTitle(item)
            .setDescription(
                `
 Seller: ${Client.users.cache.get(seller)}     
 Price: **$${price}**
 Duration: **${moment
          .duration(duration - Date.now())
          .format('D [day(s)], H [hour(s)], m [minute(s)] & s [second]')}**
 Max Bid: **$${max_bid.amount}**`
            )
            .setColor(Client.color);
        msg.edit(embed);
    }
};