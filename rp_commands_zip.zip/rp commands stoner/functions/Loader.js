const FileSystem = require('fs');

module.exports.execute = async(Client) => {
    const eventFiles = FileSystem.readdirSync('./events').filter((file) =>
        file.endsWith('.js')
    );

    for (const file of eventFiles) {
        const event = require(`../events/${file}`);
        if (event.name) {
            await Client.on(event.name, (...args) => event.execute(Client, ...args));
            console.log(`[Loader] Event ${file} has been succesufully loaded!`);
        } else continue;
    }

    const commandFiles = FileSystem.readdirSync(`./commands/`).filter((file) =>
        file.endsWith('.js')
    );
    for (const file of commandFiles) {
        const command = require(`../commands/${file}`);
        if (command.config.name && command.config.aliases) {
            Client.commands.set(command.config.name, command);
            command.config.aliases.forEach((alias) => {
                Client.aliases.set(alias, command.config.name);
            });
            console.log(
                `[Loader] Command ${command.config.name} has successfully loaded!`
            );
        } else continue;
    }
};